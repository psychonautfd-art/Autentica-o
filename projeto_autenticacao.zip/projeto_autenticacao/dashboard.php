<?php
// RF3 - Proteção: O "Guard"
require_once 'includes/verifica_sessao.php';

// Exemplo de uso da verificação de perfil
// Se esta página só pudesse ser acessada por 'admin', usaríamos:
// verificar_permissao('admin');

// Sanitização/escape ao exibir dados (Validações Mínimas)
$usuario_logado = htmlspecialchars($_SESSION['usuario']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Acesso Restrito</title>
    <style>body {font-family: Arial;} .alerta-sucesso{color:green;}</style>
</head>
<body>
    <h1>Dashboard</h1>
    <p>Bem-vindo(a), <strong><?php echo $usuario_logado; ?></strong>!</p>
    <p>Seu perfil é: <strong><?php echo htmlspecialchars($_SESSION['perfil']); ?></strong></p>

    <p>Esta é uma página protegida. Se você não estivesse logado, seria redirecionado para a tela de login.</p>
    
    <hr>
    <p><a href="logout.php">Sair (Logout)</a></p>
</body>
</html>
