<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// Bloqueio Mínimo de Tentativas (Fluxo Esperado - Validações Mínimas)
$max_tentativas = 5;
if (!isset($_SESSION['tentativas_falhas'])) {
    $_SESSION['tentativas_falhas'] = 0;
}

if ($_SESSION['tentativas_falhas'] >= $max_tentativas) {
    set_mensagem('erro', 'Acesso bloqueado por excesso de tentativas falhas. Tente novamente mais tarde.');
    redirecionar('index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validação Mínima (Campos Obrigatórios)
    if (empty($_POST['email']) || empty($_POST['senha'])) {
        set_mensagem('erro', 'Preencha todos os campos.');
        redirecionar('index.php');
    }

    $email = trim($_POST['email']);
    $senha = $_POST['senha'];

    try {
        // PDO + prepared statements (RT)
        $stmt = $pdo->prepare("SELECT id, senha_hash, perfil FROM usuarios WHERE email = :email");
        $stmt->execute([':email' => $email]);
        $usuario = $stmt->fetch();

        // RF2: Comparar credenciais com a base de dados
        if ($usuario && password_verify($senha, $usuario['senha_hash'])) {
            // Sucesso na Autenticação (RF2)
            
            // Limpa o contador de tentativas
            $_SESSION['tentativas_falhas'] = 0;
            
            // Iniciar sessão e registrar (RF2)
            $_SESSION['usuario'] = $email;
            $_SESSION['perfil'] = $usuario['perfil'];
            
            // Regeneração de ID de sessão (RT)
            session_regenerate_id(true); 
            
            set_mensagem('sucesso', 'Login realizado com sucesso! Bem-vindo(a).');
            // Redireciona para dashboard.php (Páginas Obrigatórias)
            redirecionar('dashboard.php');

        } else {
            // Credenciais inválidas (RF5)
            $_SESSION['tentativas_falhas']++;
            set_mensagem('erro', 'E-mail ou senha inválidos. Tentativas restantes: ' . ($max_tentativas - $_SESSION['tentativas_falhas']));
            redirecionar('index.php');
        }

    } catch (PDOException $e) {
        // Erro genérico
        set_mensagem('erro', 'Ocorreu um erro interno no sistema. Tente novamente mais tarde.');
        redirecionar('index.php');
    }
} else {
    // Acesso direto, redireciona para o login
    redirecionar('index.php');
}
