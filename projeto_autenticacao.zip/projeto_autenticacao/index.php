<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Login - Projeto Seguro</title>
    <style>/* Estilos básicos para usabilidade */ .alerta-erro{color:red;} .alerta-sucesso{color:green;} .alerta{padding: 10px; border: 1px solid;} body {font-family: Arial;} form {width: 300px; margin: 50px auto; padding: 20px; border: 1px solid #ccc;}</style>
</head>
<body>

    <?php echo get_mensagem(); ?>

    <form action="autentica.php" method="POST">
        <h2>Acesso Restrito</h2>
        <p>Use: teste@exemplo.com / 123456</p>

        <label for="email">E-mail:</label><br>
        <input type="email" id="email" name="email" required><br><br>

        <label for="senha">Senha:</label><br>
        <input type="password" id="senha" name="senha" required><br><br>

        <button type="submit">Entrar</button>
    </form>

</body>
</html>
