<?php
$senha_limpa = '123456';
$hash_correto = password_hash($senha_limpa, PASSWORD_DEFAULT);

echo "Senha Limpa: " . $senha_limpa . "<br>";
echo "Hash Gerado (Copie este): " . $hash_correto . "<br>";
?>
