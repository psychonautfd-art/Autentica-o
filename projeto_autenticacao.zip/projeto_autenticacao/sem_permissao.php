<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Acesso Negado</title>
    <style>body {font-family: Arial;} .alerta-erro{color:red;}</style>
</head>
<body>
    <h1>Acesso Negado</h1>
    <?php echo get_mensagem(); ?>
    <p>Você tentou acessar uma página para a qual seu perfil não possui as permissões necessárias.</p>
    <hr>
    <p><a href="dashboard.php">Voltar para a Dashboard</a></p>
    <p><a href="logout.php">Sair (Logout)</a></p>
</body>
</html>
