# Projeto de Autenticação e Controle de Acesso em PHP

Este projeto implementa um sistema de autenticação seguro em PHP, seguindo as melhores práticas de segurança e os requisitos estabelecidos.

## Requisitos Funcionais e Técnicos Implementados

* **Autenticação Segura:** Uso de `password_hash()` e `password_verify()` para senhas.
* **Conexão Segura:** Uso de `PDO` com *prepared statements* para prevenir Injeção SQL.
* **Controle de Sessão:** Uso de `session_regenerate_id(true)` após o login.
* **Proteção de Páginas:** Implementação de um "guard" (`verifica_sessao.php`) para proteger o acesso.
* **Fluxo de Login:** Validação, criação de sessão (`$_SESSION['usuario']`, `$_SESSION['perfil']`) e redirecionamento.
* **Usabilidade:** Mensagens claras de erro (RF5) e bloqueio mínimo por tentativas falhas.

##  Passos para Rodar o Projeto

1.  **Configuração do Banco de Dados:**
    * Crie um banco de dados MySQL (ex: `projeto_autenticacao`).
    * Execute o script `usuarios.sql` para criar a tabela `usuarios` e inserir o usuário de teste.
2.  **Configuração do PHP:**
    * Edite o arquivo `includes/config.php` e altere as constantes `DB_HOST`, `DB_NAME`, `DB_USER` e `DB_PASS` com suas credenciais.
3.  **Hospedagem:**
    * Coloque todos os arquivos em um servidor web (como Apache/Nginx) com suporte a PHP.
4.  **Acesso:**
    * Acesse `index.php` pelo navegador (ex: `http://localhost/index.php`).

## Usuário/Senha de Teste

| Campo | Valor |
| :--- | :--- |
| **Usuário (E-mail)** | `teste@exemplo.com` |
| **Senha** | `123456` |
| **Perfil** | `admin` |

## Descrição Breve do Fluxo

1.  O usuário acessa `index.php` e insere as credenciais.
2.  O formulário envia os dados para `autentica.php`.
3.  Em `autentica.php`, o sistema:
    * Verifica a senha com `password_verify()`.
    * Se válido: limpa o contador de falhas, registra a sessão (`$_SESSION`), regenera o ID da sessão (`session_regenerate_id(true)`) e redireciona para `dashboard.php`.
    * Se inválido: incrementa o contador de falhas, define uma mensagem de erro (RF5) e redireciona para `index.php`.
4.  Em `dashboard.php`, o arquivo `includes/verifica_sessao.php` é incluído.
    * O "guard" verifica se `$_SESSION['usuario']` existe. Se não, redireciona para `index.php` com a mensagem de sessão expirada.
5.  Em `logout.php`, a sessão é destruída e o usuário é redirecionado para `index.php`.
