
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha_hash VARCHAR(255) NOT NULL,
    perfil ENUM('admin', 'user') NOT NULL
);


INSERT INTO usuarios (email, senha_hash, perfil) VALUES
('teste@exemplo.com', '$2y$10$uAlREkLH7r.i.Fs.0YOHOuG3AK3fwnM.coSZztcpGbcMvQm65ZQjy', 'admin');
