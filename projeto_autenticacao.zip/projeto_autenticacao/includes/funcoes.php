<?php
// Função para redirecionamento seguro
function redirecionar($url) {
    header("Location: " . $url);
    exit; // RT - Importante para parar a execução após o redirecionamento
}

// Função para exibir mensagens (RF5)
function set_mensagem($tipo, $texto) {
    $_SESSION['mensagem'] = ['tipo' => $tipo, 'texto' => $texto];
}

function get_mensagem() {
    if (isset($_SESSION['mensagem'])) {
        $mensagem = $_SESSION['mensagem'];
        unset($_SESSION['mensagem']);
        return "<div class='alerta alerta-" . $mensagem['tipo'] . "'>" . htmlspecialchars($mensagem['texto']) . "</div>";
    }
    return "";
}
