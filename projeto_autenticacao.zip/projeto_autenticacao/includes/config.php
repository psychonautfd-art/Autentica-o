<?php
// RT - Configuração Opcional de Sessão (Bônus)
// Garante que o cookie de sessão só é acessível por HTTP e não por JavaScript
ini_set('session.cookie_httponly', 1);

// Se estiver em ambiente de produção (HTTPS), ative a flag secure
// if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
//     ini_set('session.cookie_secure', 1);
// }

// Inicia a sessão
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Configurações do Banco de Dados
define('DB_HOST', 'localhost');
define('DB_NAME', 'projeto_autenticacao');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Arquivo: includes/config.php
try {
    // Adicionamos ;port=3307 ao DSN
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET . ";port=3307", 
        DB_USER,
        DB_PASS,
        // ... (resto dos atributos)
    );
} catch (PDOException $e) {
    // ...
}
