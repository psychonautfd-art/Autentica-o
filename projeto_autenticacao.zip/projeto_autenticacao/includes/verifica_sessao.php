<?php
// RT - Este arquivo deve ser incluído via require_once('verifica_sessao.php')
require_once 'config.php'; // Garante que a sessão está iniciada
require_once 'funcoes.php';

// RF3 - Verificação de Sessão (Redirecionamento para index.php se ausente/expirada)
if (!isset($_SESSION['usuario'])) {
    // Validação Mínima - Exibir mensagem de sessão expirada (RF5)
    set_mensagem('erro', 'Sessão expirada ou acesso não autorizado. Faça o login novamente.');
    // Redireciona (Fluxo Esperado)
    redirecionar('../index.php'); 
}

/**
 * Função opcional para verificar o perfil.
 * * @param string|array $perfis_permitidos Um único perfil ou um array de perfis.
 */
function verificar_permissao($perfis_permitidos) {
    if (!isset($_SESSION['perfil'])) {
        // Redireciona para login (caminho de segurança, embora o check acima já resolva)
        redirecionar('../index.php'); 
    }

    $perfil_usuario = $_SESSION['perfil'];
    
    // Converte para array se for string para simplificar a lógica
    if (!is_array($perfis_permitidos)) {
        $perfis_permitidos = [$perfis_permitidos];
    }

    // RF3 - Bloqueia acesso se o perfil exigido não corresponder ao do usuário
    if (!in_array($perfil_usuario, $perfis_permitidos)) {
        // Mensagem de falta de permissão (RF5)
        set_mensagem('erro', 'Você não tem permissão para acessar esta página (Seu Perfil: ' . $perfil_usuario . ').');
        redirecionar('../sem_permissao.php');
    }
}
