<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// RF4: Encerrar sessão
session_unset();    // Limpa todas as variáveis de sessão
session_destroy();  // Destrói a sessão

set_mensagem('sucesso', 'Sessão encerrada com sucesso.');

// Redirecionar para index.php (RF4)
redirecionar('index.php');
